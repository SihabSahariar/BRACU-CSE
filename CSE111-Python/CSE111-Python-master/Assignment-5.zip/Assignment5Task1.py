check={}
s1=input()
l=s1.split(",")
for i in range(len(l)):
    s=str(l[i])
    l1=s.split(":")
    check[l1[0]]=int(l1[1])

print(check)
while True:
    s=input()
    if s=="STOP":
        break

    n=int(s)
    if n in check.values():
        print("True")
    else:
        print("False")