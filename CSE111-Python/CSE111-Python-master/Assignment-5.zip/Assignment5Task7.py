s1=input()
s2=input()
if len(s1)==len(s2):
    dict1={1:s1}
    dict2={2:s2}
    count=0
    lst=[]
    for key,value in dict1.items():
        for j in range(len(value)):
            lst.append(value[j])
    print(lst)
    for key,value in dict2.items():
        #live
        for i in range(len(value)):
            if value[i] in lst:
                count+=1
    if count==len(s1):
        print("Anagram")
    else:
        print("Not Anagram")
else:
    print("Not Anagram")
#evil
#live