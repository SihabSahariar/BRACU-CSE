dic={}
s1=input()
l=s1.split(",")
lst=[]
for i in range(len(l)):
    s2=str(l[i])
    l1=s2.split(":")
    dic[l1[0]]=l1[1]

print(dic)

#dic=[key] then [value]

dic1 = {}
lst = []
lst1 = []
for key, value in dic.items():
    if value not in lst:
        lst.append(value)
        for key1, value2 in dic.items():
            if value == value2:
                lst1.append(key1)

        dic1[value] = lst1
        lst1 = []
print(dic1)