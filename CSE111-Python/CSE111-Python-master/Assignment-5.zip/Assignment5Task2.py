mark={}
s1=input()
l=s1.split(",")
lst=[]
for i in range(len(l)):
    s2=str(l[i])
    l1=s2.split(":")
    mark[l1[0]]=int(l1[1])

print(mark)
#max_result=max(mark,key=mark.get)
#min_result=min(mark,key=mark.get)
max_result=""
min_result=""
max1=0
min1=101
for key,value in mark.items():
    if value>max1:
        max_result=key
        max1=value
    if value<min1:
        min_result=key
        min1=value



print("Minimum:",min_result)
print("Maximum:",max_result)


#Physics: 82, Math : 65,History: 75