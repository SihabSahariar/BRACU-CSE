dict1 = {}
while True:
    s=input()
    if s=="STOP":
        break
    x=int(s)
    if x not in dict1:
        dict1[x] = 1
    else:
        dict1[x] += 1

for key,values in dict1.items():
    print(key,"-",values,"times")