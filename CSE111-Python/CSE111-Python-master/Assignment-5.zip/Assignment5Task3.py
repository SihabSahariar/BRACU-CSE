number={}
i=97
while i<=106:
    n=int(input("Enter a number: "))
    if n in number.values():
        print("Duplicate")
        i=i-1
    else:
        number[chr(i)]=n
    i=i+1



print(number)