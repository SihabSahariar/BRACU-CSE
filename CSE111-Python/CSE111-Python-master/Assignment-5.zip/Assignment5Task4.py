
dict1={}
dict2={}
s1=input()
s3=input()
l=s1.split(",")
l1=s3.split(",")
for i in range(len(l)):
    s=str(l[i])
    l2=s.split(":")
    dict1[l2[0]]=int(l2[1])
for i in range(len(l1)):
    s=str(l1[i])
    l2=s.split(":")
    dict2[l2[0]]=int(l2[1])
dic={}
for k,v in dict1.items():
    if k not in dic:
        dic[k] = v
    else:
        dic[k] += v
for k,v in dict2.items():
    if k not in dic:
        dic[k]=v
    else:
        dic[k]+=v
print(dic)
lst=[]
for k,v in dic.items():
    if v not in lst:
        lst.append(v)
print(lst)
for i in range(len(lst)):
    for j in range(len(lst)-1):
        if lst[j]>lst[j+1]:
            lst[j], lst[j + 1]=lst[j+1], lst[j]
print(tuple(lst))