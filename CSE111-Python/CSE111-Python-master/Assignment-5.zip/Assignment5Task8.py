dict1={0:[" "],1:[".",",","?","!",":"],2:["A","B","C"],3:["D","E","F"],4:["G","H","I"],5:["J","K","L"],6:["M","N","O"],7:["P","Q","R","S"],8:["T","U","V"],9:["W","X","Y","Z"]}
s=input()
for i in range(len(s)):
    t=0
    s1=0
    s2=s[i]

    for k,v in dict1.items():
        if s2 in v:
            for j in range(len(v)):
                if s2==v[j]:
                    t=j
                    s1=k
                    break
    for c in range(t+1):
        print(s1,end="")

#4433555555666110966677755531111